@extends('layouts.app');

@section('content')
    <!--<h1>Inscrever Escolas</h1>

    <form method= "POST" action="{{ route('escola.store') }}" enctype="multipart/form-data">
        {{ csrf_field() }}
        <div class="col-md-4">
        <span> Nome: <input type="text" name="nome"></span></br>
        <span> Nome Fantasia: <input type="text" name="nome_fantasia"></span></br>
        <span> Tipo: <input type="text" name="tipo"></span></br>
        
        </div>
        <div class="col-md-4">
        <span> Telefone: <input type="text" name="telefone"></span></br>
        <span> Celular 1: <input type="text" name="celular1"></span></br>
        <span> Celular 2: <input type="text" name="celular2"></span></br>
        <span> Email: <input type="text" name="email"></span></br>
       
        </div>

        <div class="col-md-4">
        <span> Rua: <input type="text" name="rua"></span></br>
        <span> Bairro: <input type="text" name="bairro"></span></br>
        <span> Numero: <input type="text" name="numero"></span></br>
        <span> Complemento: <input type="text" name="complemento"></span></br>
        <span> CEP: <input type="text" name="cep"></span></br>
        <span> Cidade: <input type="text" name="cidade"></span></br>
        <span> Estado: <input type="text" name="estado"></span></br>
        <span> Pais: <input type="text" name="pais"></span></br>
     
        </div>
   

        <input type="submit">
    </form>-->
@endsection

