@extends('layouts.app')

@section('content')
<a href="{{url($document->url)}}">Open the pdf!</a>
@endsection