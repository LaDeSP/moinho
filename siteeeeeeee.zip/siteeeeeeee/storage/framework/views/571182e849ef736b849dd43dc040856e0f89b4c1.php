;
<style type="text/css">
        div.col-md-4{
            margin-top: 14px;
        }
    </style>

<?php $__env->startSection('content'); ?>
    <h1>Adicionar Inscrição</h1>

    <form method= "POST" action="<?php echo e(route('documento.store')); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <input type="text" name="help" value="<?php echo e($help); ?>" id="SI" >
        <div class="col-md-4">
            <table>
            <tr>
                <td><label>Número do Documento: </label></td>
                <td><input type="text" name="numero_documento" size="23" class="form-control"></td>
            </tr>
            <tr>
                <td><label>Tipo do Documento: </label></td>
                <td><select name="doc_type" class="form-control">
                    <?php $__currentLoopData = $documento_tipo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <option value="<?php echo e($doc_type->id); ?>"> <?php echo e($doc_type->nome); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select></td>
            </tr>
            <tr>
                <td><label>Anotação: </label></td>
                <td><input type="text" name="comentario" size="23" class="form-control"></td>
            </tr>
            <tr>
                <td><label>Anexo: </label></td>
                <td><input type="file" name="documento" size="23" class="form-control"></td>
            </tr>
            <tr>
                <td><label>Número do Documento: </label></td>
                <td><input type="text" name="numero_documento2" size="23" class="form-control"></td>
            </tr>
            <tr>
                <td><label>Tipo do Documento: </label></td>
                <td><select name="doc_type2" class="form-control">
                    <?php $__currentLoopData = $documento_tipo2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc_type2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <option value="<?php echo e($doc_type2->id); ?>"> <?php echo e($doc_type2->nome); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select></td>
            </tr>
            <tr>
                <td><label>Anotação: </label></td>
                <td><input type="text" name="comentario2" size="23" class="form-control"></td>
            </tr>
            <tr>
                <td><label>Anexo: </label></td>
                <td><input type="file" name="documento2" size="23" class="form-control"></td>
            </tr>
            <tr>
                <td><label>Número do Documento: </label></td>
                <td><input type="text" name="numero_documento3" size="23" class="form-control"></td>
            </tr>
            <tr>
                <td><label>Tipo do Documento: </label></td>
                <td><select name="doc_type3" class="form-control">
                    <?php $__currentLoopData = $documento_tipo3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc_type3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <option value="<?php echo e($doc_type3->id); ?>"> <?php echo e($doc_type3->nome); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select></td>
            </tr>
            <tr>
                <td><label>Anotação: </label></td>
                <td><input type="text" name="comentario3" size="23" class="form-control"></td>
            </tr>
            <tr>
                <td><label>Anexo: </label></td>
                <td><input type="file" name="documento3" size="23" class="form-control"></td>
            </tr>
            
            <tr>
                <td><input type="submit" class="btn-success"></td>
            </tr>
            </table>
         
        </div>
   

        
    </form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>