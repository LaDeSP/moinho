    <style type="text/css">
        div.col-md-4{
            margin-top: 14px;
        }
    </style>
;

<?php $__env->startSection('content'); ?>
    

    <form method= "POST" action="<?php echo e(route('turma.store')); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="col-md-4">
        <h1>Cadastrar Turma</h1>
        <table>
             <tr>
                <td><label>Nome: </label></td>
                <td><select name="turma" class="form-control">
                    <?php $__currentLoopData = $nome; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $turma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <option value="<?php echo e($turma->id); ?>"> <?php echo e($turma->nome_turma); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select> </td>
            </tr>
            <tr>
                <td><label>Turno: </label></td>
                <td><input type="text" name="turno" size="23" class="form-control"></td>
            </tr>
            <tr>
                <td><label>Ano: </label></td>
                <td><input type="year" name="ano" size="23" class="form-control"></td>
            </tr>
            <tr>
                <td><label>Semestre: </label></td>
                <td><input type="text" name="periodo" size="23" class="form-control"></td>
            </tr>
            <tr>
                <td><input type="submit" class="btn-success"></td>
            </tr>
        </table>
       
    
        </div>

        
    </form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>