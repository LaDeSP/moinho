<?php $__env->startSection('content'); ?>

<div class="panel panel-info">
    <div class="panel-heading">
    <table>
      <tr class="header">
            <th style="width:243px;"></th>
            <th style="width:243px;"></th>
            <th style="width:243px;"></th>
            <th style="width:243px;"></th>
    </tr>
    <td><b>Nome do Inscrito</b></td>
    <td><b>CPF do Inscrito</b></td>
    <td><b>Data de Avaliação</b></td>
    
    </table>

    </div>
      <div class="panel-body" id="teste">
      <table>
      <tr class="header">
            <th style="width:243px;"></th>
            <th style="width:243px;"></th>
            <th style="width:243px;"></th>
            <th style="width:243px;"></th>
    </tr>
      <tbody>
        <tr>
        <?php $__currentLoopData = home(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $turma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <?php if($turma->Dias>=0): ?> 
            <tr>
            <td> <?php echo e($turma->nome); ?> </td>
            <td> <?php echo e($turma->cpf); ?></td> 
            <td>  - Daqui a <?php echo e($turma->Dias); ?> dias.</td>
            </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
   


      </table>
      </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>