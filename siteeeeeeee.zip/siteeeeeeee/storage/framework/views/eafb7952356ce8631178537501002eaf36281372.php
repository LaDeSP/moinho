;

<?php $__env->startSection('content'); ?>
    <h1>Criar Nova Turma</h1>

    <form method= "POST" action="<?php echo e(route('NomeTurma.store')); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="col-md-4">
        
        <table>
        	<tr>
        		<td><label>Nome: </label></td>
        		<td><input type="text" name="nome" size="23" class="form-control"></td>
        	</tr>
        	<tr>
        		<td><input type="submit" class="btn-success"></td>
        	</tr>
        </table>
        
       
    
        </div>
     
    </form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>