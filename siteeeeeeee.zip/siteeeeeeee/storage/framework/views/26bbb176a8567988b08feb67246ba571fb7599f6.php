;

<?php $__env->startSection('content'); ?>
    <h1>Cadastrar Disciplina</h1>

    <form method= "POST" action="<?php echo e(route('disciplina.store')); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="col-md-4">
        <table>
            <tr>
                <td><label>Nome: </label></td>
                <td><input type="text" name="nome" size="23" class="form-control"></td>
            </tr>
            <tr>
                <td><label>Turno: </label></td>
                <td><input type="text" name="turno" size="23" class="form-control"></td>
            </tr>
            <tr>
                <td><label>Sala de Aula: </label></td>
                <td><input type="text" name="sala_de_aula" size="23" class="form-control"></td>
            </tr>
            <tr>
                <td><label>Professor: </label></td>
                <td><select name="colaborador_id" class="form-control">
                    <?php $__currentLoopData = $colaborador; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $professor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <?php $__currentLoopData = busca_pessoa($professor->pessoa_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($professor->id); ?>"> <?php echo e($nome->nome); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select> </td>
            </tr>
            <tr>
                <td><label>Dia da Semana: </label></td>
                <td><input type="text" name="dia_semana" size="23" class="form-control"></td>
            </tr>
            <tr>
                <td><label>Hora: </label></td>
                <td><input type="time" name="hora" size="23" class="form-control"></td>
            </tr>
            <tr>
                <td> <input type="submit" class="btn-success"></td>
            </tr>


        </table>

       

        
        
    
        </div>
       
    </form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>