<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NomeTurma extends Model
{
    protected $table = "nome_turma";
    
 


    public $timestamps = false;
}
